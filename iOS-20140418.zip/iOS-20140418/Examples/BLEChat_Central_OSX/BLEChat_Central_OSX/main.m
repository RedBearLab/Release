//
//  main.m
//  BLEChat_Central_OSX
//
//  Created by Cheong on 14-3-9.
//  Copyright (c) 2014年 RedBear. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
