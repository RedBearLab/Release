
Put these two folders to your Documents\Arduino\libraries folder.
