/** Automatically generated file. DO NOT MODIFY */
package com.redbear.bleselect;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}