
BLE Select

This demo teaches you how to scan multiple device and select one to connect. Once connected, you can connect to the last connected device without re-scan.

