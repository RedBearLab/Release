Android
=======

BLE SDK for Android (v4.3 or above)
